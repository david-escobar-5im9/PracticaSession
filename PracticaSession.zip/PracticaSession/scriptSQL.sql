create database Lab3;
use Lab3;
create table Usuario(

user nvarchar(20),
password nvarchar(20)

);

insert into Usuario() values ('David','Escobar');
 